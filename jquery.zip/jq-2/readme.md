# Exercices JQuery 2
**IMPORTANT**

Les fichiers *HTML* et *jQuery* sont fournis. **Attention** : Comme pour Bootstrap, on ne modifie pas le fichier jQuery.  
Votre code jQuery sera à écrire dans les balises : *remplacer le "ici votre code"* par votre code.

## Exercice 1
Au **clic** sur le bouton, afficher une **boite de dialogue** avec le message de votre choix.


## Exercice 2
Au **double clic**, modifier la **largeur** de l'image à 500px.


## Exercice 3
**Afficher** ou **masquer** la div text au **clic** des liens fournis.


## Exercice 4
Au **clic** sur un bouton de couleur, **modifier** la couleur du texte de la div.


## Exercice 5
Quand un champ a le **focus**, définir sa bordure à *"1px solid green"*. Quand le champ **perd le focus**, définir la bordure à *"1px solid red"*.


## Exercice 6
Au **passage** de la souris sur un bouton de couleur, **colorer** le texte.  
Le texte doit redevenir noir quand la souris **quitte** le bouton.
