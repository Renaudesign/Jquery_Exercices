# Exercices JQuery 1
**IMPORTANT**

Les fichiers *HTML* et *jQuery* sont fournis. **Attention** : Comme pour Bootstrap, on ne modifie pas le fichier jQuery.  
Votre code jQuery sera à écrire dans les balises : *remplacer le "ici votre code"* par votre code.

## Exercice 1 :
Cacher la div **text**.


## Exercice 2 :
Afficher la div **text**.


## Exercice 3 :
Changer le font-family de la div **text** en "Arial".


## Exercice 4 :
Changer la couleur de toutes les balises **li** en rouge.


## Exercice 5 :
Vider la div **secondText**.


## Exercice 6 :
**Cacher** tous les éléments de la classe **hide**.


## Exercice 7 :
**Supprimer** tous les éléments de la classe **remove**.


## Exercice 8 :
Donner à tous les éléments **li enfants** de **ol** la couleur rouge.


## Exercice 9 :
Donner aux div **firstText** et **thirdText** une bordure de 5 pixels, *verte à pointillés* ("5px green dashed").


## Exercice 10 :
Du JQuery est déjà présent et permet de cacher tous les éléments de la classe **hide**. Ajouter cette classe à la div **thirdText**.
