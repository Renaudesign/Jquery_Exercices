# Exercice Jquery 3
**IMPORTANT**  
Vous devez utiliser **jQuery** pour faire les exercices.

## Exercice 1
Construisez une page html avec un **bouton** et **un champ texte** dans lequel on affiche *le nombre de clics sur le bouton*.


## Exercice 2
Construisez une page html avec un **bouton "+"**, **un bouton "-"** et **un champ texte** dans lequel on *augmente* ou *baisse* le chiffre en fonction des boutons cliqués.


## Exercice 3
Construisez une page html avec un **bouton** et **un champ texte**.  
Le but est de trouver un nombre entre 0 et 100.  
A chaque réponse la page répond :
* Plus.
* Moins.
* Correcte.

Quand la réponse est trouvée, on obtient le nombre d'essai que l'on a fait.


## Exercice 4
Construisez une page html avec **5 boutons** et **un rectangle**.  
Chaque bouton provoque une action sur le rectangle :
* Bouton 1 : Augmente la hauteur de 10px, s'il dépasse 100px, il remet la hauteur à 10px.
* Bouton 2 : Met le rectangle en vert.
* Bouton 3 : Remet les couleurs initiales.
* Bouton 4 : Fait disparaître le rectangle.
* Bouton 5 : Fait réaparaître le rectangle.
